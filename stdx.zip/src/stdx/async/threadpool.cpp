﻿#include <stdx/async/threadpool.h>
#include <stdx/finally.h>

stdx::threadpool::impl_t stdx::threadpool::m_impl;
uint32_t stdx::_Threadpool::m_cpu_cores = cpu_cores();
uint32_t stdx::suggested_threads_number()
{
	uint32_t cores = cpu_cores();
#ifdef STDX_NOT_LIMITED_CPU_USING
	return cores * 2 + 2;
#else
	if (cores < 3)
	{
		return cores;
	}
	if (cores < 9)
	{
		return cores * 2 + 2;
	}
	else
	{
		return 20;
	}
#endif // STDX_NOT_LIMITED_CPU_USING
}

//构造函数

stdx::_Threadpool::_Threadpool() noexcept
	:m_alive_count(std::make_shared<uint32_t>(0))
	,m_free_count(std::make_shared<uint32_t>(0))
	, m_lock()
	, m_alive(std::make_shared<bool>(true))
	, m_task_queue(std::make_shared<std::queue<runable_ptr>>())
	, m_cv(std::make_shared<std::condition_variable>())
	, m_mutex(std::make_shared<std::mutex>())
{
	//初始化线程池
	init_threads();
}

//析构函数

stdx::_Threadpool::~_Threadpool() noexcept
{
	//终止时设置状态
	*m_alive = false;
#ifdef DEBUG
	printf("[Threadpool]线程池正在销毁\n");
#endif // DEBUG
}

void stdx::_Threadpool::join_handle()
{
	std::unique_lock<stdx::spin_lock> lock(m_lock);
	*m_alive_count += 1;
	lock.unlock();
	auto handle = [](std::shared_ptr<std::queue<runable_ptr>> tasks,std::shared_ptr<std::condition_variable> cond, std::shared_ptr<std::mutex> mutex, std::shared_ptr<uint32_t> count, stdx::spin_lock _lock, std::shared_ptr<bool> alive, std::shared_ptr<uint32_t> alive_count)
	{

		stdx::finally fin([mutex, alive_count]() mutable
		{
			std::unique_lock<std::mutex> lock(*mutex);
			*alive_count -= 1;
		});

		//如果存活
		while (*alive)
		{
			std::unique_lock<std::mutex> __lock(*mutex);
			//等待通知
			while (tasks->empty() && *alive)
			{
				auto r = cond->wait_for(__lock,std::chrono::minutes(5));
				if (r == std::cv_status::timeout)
				{
					std::unique_lock<stdx::spin_lock> lock(_lock);
#ifdef DEBUG
					::printf("[Threadpool]线程池等待任务超时,清除线程\n");
#endif
					*count = *count - 1;
					return;
				}
			}
			if (!(tasks->empty()))
			{
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
				//如果任务列表不为空
				//减去一个计数
				//std::unique_lock<stdx::spin_lock> lock(_lock);
				*count = *count - 1;
				//lock.unlock();
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
				//执行任务
				try
				{
#ifdef DEBUG
					::printf("[Threadpool]线程池正在获取任务\n");
#endif
					runable_ptr t = std::move(tasks->front());
					//从queue中pop
					tasks->pop();
					__lock.unlock();
#ifdef DEBUG
					::printf("[Threadpool]线程池获取任务成功\n");
#endif
					if (t)
					{
						t->run();
					}
				}
				catch (const std::exception& err)
				{
					//忽略出现的错误
#ifdef DEBUG
					::fprintf(stderr, "[Threadpool]执行任务的过程中出错,%s\n", err.what());
#endif
				}
				catch (...)
				{
				}
#ifdef DEBUG
				::printf("[Threadpool]当前剩余未处理任务数:%zu\n", tasks->size());
#endif
				//完成或终止后
				//添加计数
				//lock.lock();
				*count = *count + 1;
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
			}
			else
			{
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
				continue;
			}
		}
	};
	handle(m_task_queue,m_cv,m_mutex, m_free_count, m_lock, m_alive,m_alive_count);
}

uint32_t stdx::_Threadpool::expand_number_of_threads()
{
	if (m_cpu_cores < 2)
	{
		return m_cpu_cores;
	}
	if (m_cpu_cores > 8)
	{
		return 16;
	}
	return m_cpu_cores*2;
}

bool stdx::_Threadpool::need_expand() const
{
	return m_task_queue->size() > * m_free_count && *m_alive_count < 10 * m_cpu_cores;
}

void stdx::_Threadpool::expand(uint32_t number_of_threads)
{
	for (size_t i = 0; i < number_of_threads; i++)
	{
		add_thread();
	}
}

//添加线程
void stdx::_Threadpool::add_thread() noexcept
{
#ifdef DEBUG
	printf("[Threadpool]正在创建新线程\n");
#endif

	auto handle = [](std::shared_ptr<std::queue<runable_ptr>> tasks, std::shared_ptr<std::condition_variable> cond, std::shared_ptr<std::mutex> mutex, std::shared_ptr<uint32_t> count, stdx::spin_lock _lock, std::shared_ptr<bool> alive, std::shared_ptr<uint32_t> alive_count)
	{

		stdx::finally fin([mutex, alive_count]() mutable
			{
				std::unique_lock<std::mutex> lock(*mutex);
				*alive_count -= 1;
			});

		//如果存活
		while (*alive)
		{
			std::unique_lock<std::mutex> __lock(*mutex);
			//等待通知
			while (tasks->empty() && *alive)
			{
				auto r = cond->wait_for(__lock, std::chrono::minutes(5));
				if (r == std::cv_status::timeout)
				{
					std::unique_lock<stdx::spin_lock> lock(_lock);
#ifdef DEBUG
					::printf("[Threadpool]线程池等待任务超时,清除线程\n");
#endif
					* count = *count - 1;
					return;
				}
			}
			if (!(tasks->empty()))
			{
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
				//如果任务列表不为空
				//减去一个计数
				//std::unique_lock<stdx::spin_lock> lock(_lock);
				* count = *count - 1;
				//lock.unlock();
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
				//执行任务
				try
				{
#ifdef DEBUG
					::printf("[Threadpool]线程池正在获取任务\n");
#endif
					runable_ptr t = std::move(tasks->front());
					//从queue中pop
					tasks->pop();
					__lock.unlock();
#ifdef DEBUG
					::printf("[Threadpool]线程池获取任务成功\n");
#endif
					if (t)
					{
						t->run();
					}
				}
				catch (const std::exception& err)
				{
					//忽略出现的错误
#ifdef DEBUG
					::fprintf(stderr, "[Threadpool]执行任务的过程中出错,%s\n", err.what());
#endif
				}
				catch (...)
				{
				}
#ifdef DEBUG
				::printf("[Threadpool]当前剩余未处理任务数:%zu\n", tasks->size());
#endif
				//完成或终止后
				//添加计数
				//lock.lock();
				* count = *count + 1;
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
			}
			else
			{
#ifdef DEBUG
				::printf("[Threadpool]当前线程池空闲线程数:%u\n", *count);
#endif
				continue;
			}
		}
	};
	//创建线程
	std::thread t(handle, m_task_queue, m_cv, m_mutex, m_free_count, m_lock, m_alive, m_alive_count);
	//分离线程
	t.detach();
}

//初始化线程池

void stdx::_Threadpool::init_threads() noexcept
{
#ifdef DEBUG
	printf("[Threadpool]正在初始化线程池\n");
#endif // DEBUG
	uint32_t threads_number = suggested_threads_number();
	*m_free_count += threads_number;
	for (size_t i = 0; i < threads_number; i++)
	{
		add_thread();
	}
#ifdef DEBUG
	printf("[Threadpool]初始化完成,共创建%u条线程\n",threads_number);
#endif // DEBUG
}